import os
from colored_jones_paul_copy import Jones
import subprocess
import tempfile
import time

def do(braid, N=2):
    print(f'''

Colored Jones Execution Times Summary for Braid {braid} and Color {N}:

          ''')
    start_time = time.time()
    Jones(braid, N)
    python_time = time.time() - start_time
    try:
        start_time = time.time()
        wl_file = tempfile.NamedTemporaryFile(suffix=".wl", delete=False)
        wl_file_path = wl_file.name
        wl_code = f'''
            Quiet[<< ColorJones`];
            CJ[q, 2, {{1, 1, 1}}];
            {{t, b}} = AbsoluteTiming[CJ[q, {N}, List{braid}]];
            Export["time_file.txt",t];
        '''
        wl_file.write(wl_code.encode("utf-8"))
        wl_file.flush() 
        wl_file.close()
        proc = subprocess.run(
            ["wolframscript", "-script", wl_file_path],
            capture_output=True,
            text=True,
            check=False
        )
        if proc.returncode != 0:
            raise RuntimeError(
                f"WolframScript exited with error code {proc.returncode}:\n"
                f"Stdout: {proc.stdout}\nStderr: {proc.stderr}"
            )
        embedded_mathematica_time = time.time() - start_time
        with open("time_file.txt") as file:
            intrinsic_mathematica_time = file.readlines()[0][:-1]
        print("\tPython Time:", python_time)
        print("\tIntrinsic Mathematica Time:", intrinsic_mathematica_time)
        print("\tEmbedded Mathematica Time:", embedded_mathematica_time)
        print("\n")
    finally:
        if os.path.exists(wl_file.name):
            os.remove(wl_file.name)
        if os.path.exists("time_file.txt"):
            os.remove("time_file.txt")
    
if __name__ == "__main__":
    
    do([1, 1, 1, 1, 1, 2, -1, 2, -3, 2, -3], N=4)
    # do([1, 1, 1], N=4)

    # add in knots of various crossing numbers

    pass