import csv

def tsv_to_dicts(csv_file_path):
    data_list = []
    with open(csv_file_path, 'r') as csv_file:
        csv_reader = csv.DictReader(csv_file, delimiter='\t')
        for row in csv_reader:
            data_list.append(row)
    return data_list


def write_dicts_to_tsv(data, tsv_file_path):
    # Get the first row from the generator
    data = iter(data)
    try:
        first_row = next(data)
    except StopIteration:
        raise ValueError("The generator is empty. Cannot determine fieldnames.")

    with open(tsv_file_path, 'w', newline='') as tsvfile:
        writer = csv.DictWriter(tsvfile, delimiter='\t', fieldnames=first_row.keys())
        writer.writeheader()
        
        # Write the first row
        writer.writerow(first_row)
        
        # Write the remaining rows
        for row in data:
            writer.writerow(row)


def multiply_polys(poly1,poly2):
    expanded = []
    for (p1,c1) in poly1:
        for (p2,c2) in poly2:
            expanded.append((p1+p2, c1*c2))
    res = {}
    for p,c, in expanded:
        if p not in res:
            res[p] = 0
        res[p] += c

    return list(sorted(res.items(), key=lambda x:x[0]))


def multiply_polys_many(*ps):
    p = ps[0]
    for i in range(1,len(ps)):
        p = multiply_polys(p,ps[i])
    return p


def eval_poly_coeffs(coeffs, x):
    res = 0
    for power, coeff in coeffs:
        res += coeff * (x ** power)
    return res


def format_large_number(number):
    """
    Format a large number into an approximate value with 3 significant digits.
    Examples:
        78103123123 -> "78.1 billion"
        1234567 -> "1.23 million"
    """
    if number < 1_000:
        return f"{number}"
    
    suffixes = [
        (1_000_000_000_000, "trillion"),
        (1_000_000_000, "billion"),
        (1_000_000, "million"),
        (1_000, "thousand")
    ]
    
    for threshold, suffix in suffixes:
        if number >= threshold:
            value = number / threshold
            return f"{value:.3g} {suffix}"
    
    return str(number)  # Fallback for very small values
