import requests
import os
import csv
import json
from utils import tsv_to_dicts
from snappy import Link

class Knot:
    def __init__(self, name, pd_code, **kwargs):
        self.name = name
        self.pd_code = pd_code
        self.crossings = len(pd_code)
        self.mirror_name = kwargs['mirror']
        self.jones = kwargs['jones_polynomial']
        self.colored_jones3 = kwargs['colored_jones3']
        self.colored_jones4 = kwargs['colored_jones4']
        self.colored_jones5 = kwargs['colored_jones5']
        self.colored_jones6 = kwargs['colored_jones6']
    
    def snappy_link(self):
        return Link(self.pd_code)
    
    def __eq__(self, value: object) -> bool:
        if self.crossings > 10 or value.crossings > 10:
            raise ValueError('Cannot compare knots with more than 10 crossings')
        # fact: if two knots <=10 crossings have the same colored_jones4, they are the same knot
        return self.colored_jones4 == value.colored_jones4

    def __hash__(self) -> int:
        if self.crossings > 10:
            raise ValueError('Cannot hash knots with more than 10 crossings')
        # fact: if two knots <=10 crossings have the same colored_jones4, they are the same knot
        return hash(self.colored_jones4)
    
    def __str__(self) -> str:
        return self.name
    
    def __repr__(self) -> str:
        return f'Knot({self.name})'
    
    def get_colored_jones(self, color):
        if color == 1:
            return ((0,1),)
        elif color == 2:
            return self.jones
        elif color == 3:
            return self.colored_jones3
        elif color == 4:
            return self.colored_jones4
        elif color == 5:
            return self.colored_jones5
        elif color == 6:
            return self.colored_jones6
        else:
            raise ValueError('Must use 1 <= color <= 6')

def download_knots():
    # url = "http://127.0.0.1:5000/?tsv=1"
    url = "https://yakdb.org/?tsv=1"
    output_file = "./knots.tsv"

    response = requests.get(url)
    if response.status_code == 200:
        with open(output_file, "wb") as file:
            file.write(response.content)
        print("File downloaded successfully.")
    else:
        print("Failed to download the file.")

def tuple_of_tuples(list_of_lists):
    return tuple(tuple(l) for l in list_of_lists)

def get_all_knots():
    if not os.path.exists("knots.tsv"):
        download_knots()
    knots = tsv_to_dicts("knots.tsv")
    res = []
    for k in knots:
        jones = {}
        jones['jones_polynomial'] = tuple_of_tuples(json.loads(k['jones_polynomial']))
        jones['colored_jones3'] =   tuple_of_tuples(json.loads(k['colored_jones3']))
        jones['colored_jones4'] =   tuple_of_tuples(json.loads(k['colored_jones4']))
        jones['colored_jones5'] =   tuple_of_tuples(json.loads(k['colored_jones5']))
        jones['colored_jones6'] =   tuple_of_tuples(json.loads(k['colored_jones6']))
        pd_code = tuple_of_tuples(json.loads(k['pd_code']))
        res.append(Knot(k['id'], pd_code, mirror=k['mirror'], **jones))
    return res

_knot_lookup_by_name = {}
def get_knot_by_name(name):
    if not _knot_lookup_by_name:
        print('building knot lookup')
        for knot in get_all_knots():
            # print(knot.name)
            _knot_lookup_by_name[knot.name] = knot
    return _knot_lookup_by_name[name]
    
def lookup_mirror(knot):
    return get_knot_by_name(knot.mirror_name)
    
if __name__ == "__main__":
    download_knots()
    knots = get_all_knots()
    print('got %d knots from yakdb.org' % len(knots))