from knots import get_all_knots
from colored_jones_efficient_stable_big_knots import Jones, format

all_knots = get_all_knots()
knots_to_test = all_knots[1:100]
colors_to_test = range(2,3)

for k in knots_to_test:
    if '#' not in k.name:
        print('knot:', k.name)
        braid = k.snappy_link().braid_word()
        print('braid:', braid)
        for color in colors_to_test:
            print('color:',color)

            ### TOBY'S RESULT
            jones_coeffs = tuple(format(Jones(braid,N=color)))
            print('    Toby:',jones_coeffs)
            # print('    mirror', tuple(format(Jones([-x for x in braid],N=color))))

            ### MATHEMATICA RESULT
            print('    Mathematica:',k.get_colored_jones(color))
            assert jones_coeffs == k.get_colored_jones(color)
